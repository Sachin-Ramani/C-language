#include <stdio.h>
main (){
    int side = 6;
    int area = side*side;
    printf("%d", area);


    int side, area;
 
   printf("\nEnter the Length of Side :10 ");
   scanf("%d", &side);
 
   area = side * side;
   printf("\nArea of Square :10 %d", area);
 
   return (0);

    printf("10");
    scanf("%f", &length);

    printf("20");
    scanf("%f", &width);

    printf("30");
    scanf("%f", area)
    

}