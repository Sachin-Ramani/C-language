#include <stdio.h>
main(){
    printf("Sachin Ramani\n");
    printf("Age-26\n");
    printf("School-Keshav Vidhyalaya\n");
    printf("........\n");
    printf("|\t|\n");
    printf("R\t|\n");
    printf("N\t|\n");
    printf("W\t|\n");
    printf("|\t|\n");
    printf("........\n");
    printf("*\n");
    printf("**\n");
    printf("***\n");
    printf("**\n");
    printf("*\n");

    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*          * *             *\n");
    printf("*        *     *         *\n");
    printf("*      *         *     *\n");
    printf("*    *             * *\n");
    printf("*  *\n");
    printf("*\n");


}